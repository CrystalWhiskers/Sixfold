extends SceneTree

## Win-rate measurement. One unit type on TEAM_A against a fixed mixed line on
## TEAM_B, many seeded rounds. Numbers, not guesses.

const RUNS := 400

var _roster: LoadoutData = null


func _pick(id: String) -> UnitData:
	for u in _roster.units:
		if String(u.id) == id:
			return u
	push_error("no such unit: " + id)
	return null


func _line(board: BoardModel, team: int, spec: Array) -> Array[UnitInstance]:
	## spec: [[id, tier], ...] placed into that team's deploy cells in order.
	var cells := board.deploy_cells(team)
	var out: Array[UnitInstance] = []
	var i := 0
	for row in spec:
		if i >= cells.size():
			break
		var d := BoardModel.at_tier(_pick(row[0]), row[1])
		var u := UnitInstance.create(d, team)
		if board.force_place(u, cells[i]):
			out.append(u)
		i += 1
	return out


func _run(a_spec: Array, b_spec: Array, a_buff: StringName,
		rarity: BuffData.Rarity) -> Dictionary:
	var wins := [0, 0, 0]
	var pool := BuffPool.new()
	pool.load_all()
	var buff: BuffData = null if a_buff == &"" else pool.by_id(a_buff)
	for i in RUNS:
		BoardModel.reset_map()
		var b := BoardModel.new()
		_line(b, BoardModel.TEAM_A, a_spec)
		_line(b, BoardModel.TEAM_B, b_spec)
		var sim := CombatSim.new()
		if buff != null:
			var tb := TeamBuffs.new()
			tb.add(buff, rarity)
			sim.team_buffs[BoardModel.TEAM_A] = tb
		sim.setup(b, i * 37 + 11)
		var w := sim.run()
		wins[w if w >= 0 else 2] += 1
	var decisive: int = wins[0] + wins[1]
	return {a = wins[0], b = wins[1], draw = wins[2],
		rate = float(wins[0]) / maxf(float(decisive), 1.0)}


func _report(label: String, r: Dictionary) -> void:
	print("  %-46s A %3d / B %3d / draw %2d  ->  %5.1f%%" % [
		label, r.a, r.b, r.draw, float(r.rate) * 100.0])


func _initialize() -> void:
	_roster = load("res://data/loadouts/roster.tres") as LoadoutData
	# A fixed, ordinary five-unit opposing line. Same on both sides for the
	# baseline, so anything that is not the swapped unit is held still.
	var stock := [["warden", 2], ["archer", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]

	print("\n=== baseline ===")
	_report("mirror (stock v stock)", _run(stock, stock, &"", BuffData.Rarity.GOLD))

	print("\n=== the Usurper ===")
	var with_usurper := [["usurper", 2], ["archer", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]
	_report("one Usurper T2 in place of the Warden T2",
		_run(with_usurper, stock, &"", BuffData.Rarity.GOLD))
	_report("  + bronze Reins",
		_run(with_usurper, stock, &"reins", BuffData.Rarity.BRONZE))
	_report("  + silver Reins",
		_run(with_usurper, stock, &"reins", BuffData.Rarity.SILVER))
	_report("  + gold Reins",
		_run(with_usurper, stock, &"reins", BuffData.Rarity.GOLD))
	var two_usurpers := [["usurper", 2], ["usurper", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]
	_report("two Usurpers T2", _run(two_usurpers, stock, &"", BuffData.Rarity.GOLD))
	var high_usurper := [["usurper", 4], ["archer", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]
	var stock_low := [["warden", 2], ["archer", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]
	_report("Usurper T4 against a line topping out at T2",
		_run(high_usurper, stock_low, &"", BuffData.Rarity.GOLD))
	var low_usurper := [["usurper", 1], ["archer", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]
	var stock_high := [["warden", 4], ["archer", 4], ["warden", 3],
		["archer", 3], ["seraph", 3]]
	_report("Usurper T1 against a line that outranks it everywhere",
		_run(low_usurper, stock_high, &"", BuffData.Rarity.GOLD))
	var warden_high := [["warden", 1], ["archer", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]
	_report("  (same, with a plain Warden T1 instead)",
		_run(warden_high, stock_high, &"", BuffData.Rarity.GOLD))

	print("\n=== the Aegis at 75%% resist ===")
	var with_aegis := [["aegis", 2], ["archer", 2], ["warden", 1],
		["archer", 1], ["seraph", 1]]
	_report("one Aegis T2 in place of the Warden T2",
		_run(with_aegis, stock, &"", BuffData.Rarity.GOLD))
	_report("  + gold Retaliation",
		_run(with_aegis, stock, &"retaliation", BuffData.Rarity.GOLD))
	var all_aegis := [["aegis", 2], ["aegis", 2], ["aegis", 1],
		["aegis", 1], ["aegis", 1]]
	_report("a whole line of Aegis", _run(all_aegis, stock, &"", BuffData.Rarity.GOLD))

	print("\n=== ranged units holding their distance ===")
	var bows := [["archer", 2], ["archer", 2], ["archer", 1],
		["archer", 1], ["archer", 1]]
	var blades := [["warden", 2], ["warden", 2], ["warden", 1],
		["warden", 1], ["warden", 1]]
	_report("all bows against all blades", _run(bows, blades, &"", BuffData.Rarity.GOLD))
	_report("all blades against all bows", _run(blades, bows, &"", BuffData.Rarity.GOLD))
	quit()
